import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child2',
  templateUrl: './child2.component.html',
  styleUrls: ['./child2.component.css']
})
export class Child2Component implements OnInit {

  @Input() data:any;
  @Output() outputMsg:any = new EventEmitter();
  empId: any = 0;

  constructor() { }

  ngOnChanges() {
    // this.outputMsg.emit("employee no. :"+this.data);
    // this.outputMsg.emit(this.uniqueId(0,100));
    // this.outputMsg.emit(this.data);

    if (this.data>0) {
      this.empId++;
      this.outputMsg.emit(this.empId);
    }
  }

  ngOnInit(): void {
  }
}
