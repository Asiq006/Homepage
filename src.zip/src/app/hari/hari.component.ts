import { Component, OnInit } from '@angular/core';
import { FormControl, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from './auth.service';

@Component({
  selector: 'app-hari',
  templateUrl: './hari.component.html',
  styleUrls: ['./hari.component.css']
})
export class HariComponent implements OnInit {
  title = 'employee-portal';
  loginForm: any;
  listdata: any;
  submitted: boolean = false;
  isUserExists: boolean = false;
  show: boolean = false;
  submittedIndex: number = 0;
  noOfEmployees: number = 0;
  empCount: number = 0;
  empData: number = 0;
  Country : any = [];
  states : any = [];
  City : any = [];
  eachObj : any ;
  display: boolean=true;
  display1: boolean=true;
  hideCity: boolean=true;
  width = 0;
  proWidth = "0%";
  count=0;
  return=false;


  searchTerm= new FormControl();
  cities: string[]=['Chennai','madurai'];
 





  constructor(private fb: FormBuilder, private auth : AuthService) { }

  ngOnInit() {
    this.initializeForm();
    this.listdata = [];
    this.Country = this.auth.country();
    console.log(this.Country);
    this.bringCities();
  
  }


  initializeForm(): void {
    this.loginForm = this.fb.group({
      empId: ['', Validators.max(1000)],
      fname: ['', [Validators.required, Validators.minLength(3)]],
      lname: ['',[Validators.required, Validators.minLength(1)]],
      gender: ['', Validators.required],
      dob: ['',[Validators.required, Validators.pattern(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/)]],
      age: ['', Validators.required],
      email: ['', Validators.email],
      college: ['', Validators.required],
      branch: ['', Validators.required],
      yop: ['', Validators.required],
      cgpa: ['', Validators.required],
      degree: ['', Validators.required],
      address: ['', Validators.minLength(5)],
      city: ['', Validators.required],
      state: ['', Validators.required],
      country: ['', Validators.required]
    });

  }
  
  reset() {
    this.loginForm.reset();
  }
  form(){
    this.submitted=false;
  }
  get empId() {
    return this.loginForm.get('empId');
    
  }
  get email() {
    return this.loginForm.get('email');  
  }
  get fname() {
    return this.loginForm.get('fname');    
  }

  get age() {
    return this.loginForm.get('age');
  }

  get dob() {
    return this.loginForm.get('dob');
  }

  get address() {
    return this.loginForm.get('address');
  }

  get city() {
    return this.loginForm.get('city');
  }

  get state() {
    return this.loginForm.get('state');
  }

  get country() {
    return this.loginForm.get('country');
  }

  deleteRecord(a: any) {
    // this.noOfEmployees = this.noOfEmployees - 1;
    this.listdata.splice(a, 1);
    this.empData--;
    // this.edetails(a); 
  }
  changeCountry(e : any) {
    console.log(e.value);
  
  }

  changeState(e : any) {
    this.states = this.auth.state().filter(i => i.id == e.value.id);
    this.hideCity=false;
  }

  changeCity(e: any) {
   this.City = this.auth.city().filter(i => i.sid == e.value.sid);
   this.hideCity=false;
  }


  

  // forCountry(e: any){
  //   // console.log(e.value);
  //   this.display1=false;
  //   this.Country=this.auth.country().filter(i=> i.id == e.value.id);
  // }

  toBringState(e: any){
    this.display=false;
    this.states= this.auth.state().filter(i=> i.sid == e.value.sid);
    this.display1=false;
    if(e.value.sid<=3){
      this.Country=this.auth.country().filter(i=> i.id == 1);
    }
    else if(e.value.sid>3 && e.value.sid<=6){
      this.Country=this.auth.country().filter(i=> i.id == 2);
    }
    else if(e.value.sid>6 && e.value.sid<=9){
      this.Country=this.auth.country().filter(i=> i.id == 3);
    }
    // console.log(this.states);
    
  }
  bringCities(){
    this.City=this.auth.city();
  }

  add(): void {
   
    if (this.loginForm.value.name != "" && this.loginForm.value.email != "") {
      console.log("If works!..");
      let isUserExists = this.chkUserExists(this.loginForm);
      console.log(isUserExists);
      if (isUserExists == true) {
        this.showMessage("User Exists...!")
      }
      else {
        this.listdata.push(this.loginForm.value);
        this.showMessage("Employee added successfully..!");
        this.loginForm.reset();
        this.proWidth="0%";
        this.City=this.auth.city();
        this.hideCity=true;
        this.submitted = true;
        this.empCount++;
        this.empData++;
        this.return=true;
        
        
      }
    }
    else { }
  }

  forTable(){
    this.return=false;
  }



  chkUserExists(userForm: any) {
    for (let i = 0; i < this.listdata.length; i++) {
      if (this.listdata[i].fname == userForm.value.fname && this.listdata[i].email == userForm.value.email) {
        this.isUserExists = true;
      }
    }
    return this.isUserExists;
  }

  showMessage(msg: string) {
    alert(msg);
  }

  edetails(i: number) {
    this.submittedIndex = i;
    this.show = true;
  }

  displaymsg(event: any) {
    console.log(event);
    if (this.listdata.length > 0) {
      this.listdata[this.listdata.length - 1].empId = event;
    }
  }

  progressBar() {
      this.count = 0; 
      Object.values(this.loginForm.controls).forEach((i:any)=>{if(!i.errors) this.count++;})
      this.proWidth = (this.count /16 * 100)  + '%';
    }

}
