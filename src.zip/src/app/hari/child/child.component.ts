import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  @Input() data: any;
  @Input() empData: any;
  employeeId: number = 0;
  @Output() outputMsg: any = new EventEmitter;
  constructor() {
  }

  ngOnChanges() {
    if(this.empData >0){
      this.outputMsg.emit(this.empData);
    }
    if (this.data > 0) {
      // this.employeeId = this.employeeId + 1
      this.outputMsg.emit(this.data)
    }
  }


  ngOnInit(): void {
  }

}
