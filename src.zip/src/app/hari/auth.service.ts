import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor() { }

  country() {
  return [
    {
      id: 1,
      name: 'India'
    },
    {
      id: 2,
      name: 'Pakistan'
    },
    {
      id: 3,
      name: 'Bangladesh'
    }
  ]
}

state(){
  return[
    {
      id: 1,
      sid : 1,
      name : 'TamilNadu'
    },
    {
      id: 1,
      sid : 2,
      name : 'Kerala'
    },
    {
      id: 1,
      sid : 3,
      name : 'Karnataka'
    },
    {
      id: 2,
      sid : 4,
      name : 'Balochistan'
    },
    {
      id: 2,
      sid : 5,
      name : 'Khyber Pakhtunkhwa'
    },
    {
      id: 2,
      sid : 6,
      name : 'Sindh'
    },
    {
      id: 3,
      sid : 7,
      name : 'Barishal'
    },
    {
      id: 3,
      sid : 8,
      name : 'Chattogram'
    },
    {
      id: 3,
      sid : 9,
      name : 'Dhaka'
    }
  ]
}

city(){
  return[
    {
      sid : 1,
      name : 'Chennai'
    },
    {
      sid: 1,
      name : 'Madurai'
    },
    {
      sid: 1,
      name : 'Coimbatore'
    },
    {
      sid: 2,
      name : 'Trivandrum'
    },
    {
      sid: 2,
      name : 'Kochin'
    },
    {
      sid: 2,
      name : 'Allepey'
    },
    {
      sid: 3,
      name : 'Bengaluru'
    },
    {
      sid: 3,
      name : 'Coorg'
    },
    {
      sid: 3,
      name : 'Mysuru'
    },
    {
      sid: 4,
      name : 'PC1'
    },
    {
      sid: 4,
      name : 'PC2'
    },
    {
      sid: 4,
      name : 'PC3'
    },
    {
      sid: 5,
      name : 'PC4'
    },
    {
      sid: 5,
      name : 'PC5'
    },
    {
      sid: 5,
      name : 'PC6'
    },
    {
      sid: 6,
      name : 'PC7'
    },
    {
      sid: 6,
      name : 'PC8'
    },
    {
      sid: 6,
      name : 'PC9'
    },
    {
      sid: 7,
      name : 'BC1'
    },
    {
      sid: 7,
      name : 'BC2'
    },
    {
      sid: 7,
      name : 'BC3'
    },
    {
      sid: 8,
      name : 'BC4'
    },
    {
      sid: 8,
      name : 'BC5'
    },
    {
      sid: 8,
      name : 'BC6'
    },
    {
      sid: 9,
      name : 'BC7'
    },
    {
      sid: 9,
      name : 'BC8'
    },
    {
      sid: 9,
      name : 'BC9'
    }
  ]
}
}
