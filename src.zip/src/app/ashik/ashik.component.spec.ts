import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AshikComponent } from './ashik.component';

describe('AshikComponent', () => {
  let component: AshikComponent;
  let fixture: ComponentFixture<AshikComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AshikComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AshikComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
