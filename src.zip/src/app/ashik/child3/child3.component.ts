import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child3',
  templateUrl: './child3.component.html',
  styleUrls: ['./child3.component.css']
})
export class Child3Component implements OnInit {

  @Input() data:any;
  @Output() outputMsg:any = new EventEmitter();
  empId:any = 0
  constructor() { }
  ngOnChanges(): void {
    if (this.data>0) {
      this.empId++;
      this.outputMsg.emit(this.empId);  
    }
   
    
  }

  ngOnInit(): void {
    
   
  }

}
