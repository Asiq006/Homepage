import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AbhishekComponent } from './abhishek/abhishek.component';
import { AppComponent } from './app.component';
import { AshikComponent } from './ashik/ashik.component';
import { HariComponent } from './hari/hari.component';

const routes: Routes = [

  { path: '', redirectTo: 'AppComponent', pathMatch: 'full' },
    {path:'hari', component: HariComponent},
    {path:'ashik', component: AshikComponent},
    {path:'abhishek', component: AbhishekComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
