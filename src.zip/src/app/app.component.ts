import { Component } from '@angular/core';

@Component({
  selector: '3',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'home-page';
  result: boolean=true;
  back: boolean=false;
  hide(){
    this.result=false;
    this.back=true;
  }
  backTo(){
    this.result=true;
    this.back=false;
  }
}
