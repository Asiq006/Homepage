import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HariComponent } from './hari/hari.component';
import { ChildComponent } from './hari/child/child.component';
import { AbhishekComponent } from './abhishek/abhishek.component';
import { Child2Component } from './abhishek/child2/child2.component';
import { AshikComponent } from './ashik/ashik.component';
import { Child3Component } from './ashik/child3/child3.component';


@NgModule({
  declarations: [
    AppComponent,
    HariComponent,
    ChildComponent,
    AbhishekComponent,
    Child2Component,
    AshikComponent,
    Child3Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
